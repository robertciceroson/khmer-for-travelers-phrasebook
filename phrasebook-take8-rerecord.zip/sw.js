// Khmer for Travelers Phrasebook: offline cache. (c) 2026 Robert Son.
const VERSION = 'kftp-v9';
const FILES = [
  './', './index.html', './privacy.html', './manifest.webmanifest', './fonts/fonts.css',
  './fonts/kantumruy-pro-khmer-400-normal.woff2', './fonts/kantumruy-pro-khmer-500-normal.woff2', './fonts/kantumruy-pro-khmer-700-normal.woff2',
  './fonts/kantumruy-pro-latin-400-normal.woff2', './fonts/kantumruy-pro-latin-500-normal.woff2', './fonts/kantumruy-pro-latin-700-normal.woff2',
  './fonts/moul-khmer-400-normal.woff2', './fonts/moul-latin-400-normal.woff2',
  './icons/icon-192.png', './icons/icon-512.png', './icons/apple-touch-icon.png', './icons/favicon-32.png',
  './audio/001.m4a', './audio/002.m4a', './audio/003.m4a', './audio/004.m4a', './audio/005.m4a', './audio/049.m4a', './audio/050.m4a', './audio/051.m4a', './audio/052.m4a', './audio/053.m4a', './audio/054.m4a', './audio/055.m4a', './audio/056.m4a', './audio/057.m4a', './audio/058.m4a', './audio/059.m4a', './audio/060.m4a', './audio/061.m4a', './audio/062.m4a', './audio/063.m4a', './audio/064.m4a', './audio/065.m4a', './audio/066.m4a', './audio/067.m4a', './audio/068.m4a', './audio/069.m4a', './audio/070.m4a', './audio/071.m4a', './audio/165.m4a', './audio/166.m4a', './audio/167.m4a', './audio/168.m4a', './audio/169.m4a', './audio/170.m4a', './audio/171.m4a', './audio/172.m4a', './audio/173.m4a', './audio/174.m4a', './audio/175.m4a', './audio/176.m4a', './audio/177.m4a', './audio/178.m4a', './audio/179.m4a', './audio/180.m4a', './audio/181.m4a', './audio/182.m4a', './audio/183.m4a', './audio/184.m4a', './audio/185.m4a', './audio/186.m4a', './audio/187.m4a', './audio/188.m4a', './audio/189.m4a', './audio/190.m4a', './audio/191.m4a'
];
self.addEventListener('install', (e) => {
  e.waitUntil(caches.open(VERSION).then((c) => c.addAll(FILES)).then(() => self.skipWaiting()));
});
self.addEventListener('activate', (e) => {
  e.waitUntil(caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== VERSION).map((k) => caches.delete(k)))).then(() => self.clients.claim()));
});
self.addEventListener('fetch', (e) => {
  const req = e.request;
  if (req.method !== 'GET' || new URL(req.url).origin !== self.location.origin) return;
  if (req.mode === 'navigate') {
    // Pages: try the network first so updates arrive, fall back to the saved copy offline.
    e.respondWith(fetch(req).then((res) => { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); return res; })
      .catch(() => caches.match(req).then((r) => r || caches.match('./index.html'))));
    return;
  }
  e.respondWith(caches.match(req).then((r) => r || fetch(req).then((res) => { const copy = res.clone(); caches.open(VERSION).then((c) => c.put(req, copy)); return res; })));
});
